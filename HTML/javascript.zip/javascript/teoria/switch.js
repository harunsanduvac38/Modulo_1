
let num = 3;

switch (num){
    case 1:
        console.log('Vale 1');
        break;
    case 2:
        console.log('Vale 2');
        break;
    case 3:
        console.log('Vale 3');
        break;
    case 4:
        console.log('Vale 4');
        break;
    case 5:
        console.log('Vale 5');
        break;
    case 6:
        console.log('Vale 6');
        break;
    case 7:
    case 8:
    case 9:
    case 10:
        console.log('Vale mucho');
        break;
    default:
        console.log('Valor incorrecto');
}

console.log('FIN');