
let nro = 8;

if (nro == 0)
    console.log('mje 1');
else
    console.log('mje else');

console.log('mje 2');
console.log('mje 3');