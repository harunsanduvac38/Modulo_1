const read = require("../leer.js");


let nombreMes = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Dicembre'];

for(let i = 0; i<nombreMes.length; i++){
    console.log(nombreMes[i]);
}